opencv_version = "4.6.0.66"
contrib = False
headless = False
ci_build = True